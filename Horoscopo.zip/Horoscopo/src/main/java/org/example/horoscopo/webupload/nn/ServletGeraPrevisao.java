package org.example.horoscopo.webupload.nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;

@WebServlet(
        name = "ServletGeraPrevisao",
        urlPatterns = {"/ServletGeraPrevisao"}
)
public class ServletGeraPrevisao extends HttpServlet {
    public ServletGeraPrevisao() {
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession sessao = request.getSession(true);
        new String();

        String data;
        try {
            data = request.getParameter("data");
        } catch (Exception var20) {
            data = "01-01-2000";
        }

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Throwable var6 = null;

        try {
            VerificaSigno ver = new VerificaSigno();
            int num_sig = ver.RetornaSigno(data);
            RandomAccessFile raf = new RandomAccessFile(request.getServletContext().getRealPath("") + "//horoscopo.txt", "r");

            String dados;
            for(int i = 0; i < num_sig; ++i) {
                dados = raf.readLine();
            }

            dados = raf.readLine();
            raf.close();
            out.println(dados.split("#")[2]);
        } catch (Throwable var21) {
            var6 = var21;
            throw var21;
        } finally {
            if (out != null) {
                if (var6 != null) {
                    try {
                        out.close();
                    } catch (Throwable var19) {
                        var6.addSuppressed(var19);
                    }
                } else {
                    out.close();
                }
            }

        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.processRequest(request, response);
    }

    public String getServletInfo() {
        return "Short description";
    }
}

