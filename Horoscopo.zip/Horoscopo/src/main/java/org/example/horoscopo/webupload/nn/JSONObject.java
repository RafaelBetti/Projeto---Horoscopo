package org.example.horoscopo.webupload.nn;

public class JSONObject {
    public void put(String prediction, String previsao) {

    }
}
