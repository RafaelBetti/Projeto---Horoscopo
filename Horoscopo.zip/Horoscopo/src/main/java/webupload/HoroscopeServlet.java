package webupload;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.horoscopo.webupload.nn.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class HoroscopeServlet extends HttpServlet {

    private Map<String, String[]> horoscopoData = new HashMap<>();

    @Override
    public void init() throws ServletException {
        super.init();
        carregarHoroscopo();
    }

    private void carregarHoroscopo() {
        String arquivo = getServletContext().getRealPath("/WEB-INF/horoscope.txt");
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes.length == 4) {
                    horoscopoData.put(partes[0], new String[]{partes[1], partes[2], partes[3]});
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sign = request.getParameter("sign").toLowerCase();

        String[] dados = horoscopoData.get(sign);
        if (dados != null) {
            String nomeSigno = dados[0];
            String caminhoImagem = dados[1];
            String previsao = dados[2];

            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("prediction", previsao);
            jsonResponse.put("imagePath", caminhoImagem);

            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
            out.flush();
        } else {
            // Tratamento para caso o signo não seja encontrado
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Signo não encontrado");
        }
    }
}

