package webupload;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/LoginServlet")

public class LoginServlet extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String email = request.getParameter("username");
        String senha = request.getParameter("password");

        // Verifica se o email é sintaticamente válido (você pode usar uma expressão regular aqui)
        if (email != null && email.contains("@") && senha != null) {
            String username = email.split("@")[0]; // Extrai a parte antes do '@'
            String senhaCorreta = new StringBuilder(username).reverse().toString(); // Inverte o username

            // Validação da senha
            if (senha.equals(senhaCorreta)) {
                // Login válido, cria sessão e redireciona
                HttpSession session = request.getSession();
                session.setAttribute("user", email);

                // Redireciona para a página do horóscopo
                response.sendRedirect("Form.jsp");
            } else {
                // Senha incorreta, redireciona de volta ao login
                response.sendRedirect("index.jsp");
            }
        } else {
            // Email inválido, redireciona de volta ao login
            response.sendRedirect("index.jsp");
        }
    }
}
